int main(void){
  int x=3;
  int y = x+1;
  char z = 12;
  return 0;
}
