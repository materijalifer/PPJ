char x[3] = "\\"";


int main(void) {return 0;}