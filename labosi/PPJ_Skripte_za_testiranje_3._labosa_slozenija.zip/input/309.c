int main(void) {
  char c;
  c = 'at';
  return 0;
}
