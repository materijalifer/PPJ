int main(int a) {
  return 5;
}