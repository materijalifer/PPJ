char a[2]={'c'};
char main(void)
{
  return a[1];
}