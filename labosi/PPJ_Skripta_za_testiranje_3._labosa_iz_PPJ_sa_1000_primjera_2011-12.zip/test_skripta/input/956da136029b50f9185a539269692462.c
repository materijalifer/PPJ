int b = -345;

int main(void) {
  return 0;
}