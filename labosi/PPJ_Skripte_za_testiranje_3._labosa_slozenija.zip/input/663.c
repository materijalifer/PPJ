int main(void) {
  int f = 6;
  int a[3] = {f+sd,2,3+4+"a"};
  return 0;
}
