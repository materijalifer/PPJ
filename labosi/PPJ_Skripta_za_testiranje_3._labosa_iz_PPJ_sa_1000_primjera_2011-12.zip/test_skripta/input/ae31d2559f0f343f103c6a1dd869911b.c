
char a[4]="\";
