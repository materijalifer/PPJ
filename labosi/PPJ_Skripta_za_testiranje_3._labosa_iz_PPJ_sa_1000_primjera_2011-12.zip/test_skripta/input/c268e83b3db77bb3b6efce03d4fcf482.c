
int a[1025];

int main(void) {
  return 0;
}