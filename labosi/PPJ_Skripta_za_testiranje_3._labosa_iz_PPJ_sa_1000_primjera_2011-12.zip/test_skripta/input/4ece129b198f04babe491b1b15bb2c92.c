int a[2]={2};
char b[200]="   \"  \0  \n   '  ";

char x = '"';
char gf[2] = "'";
char gff[2] = "\"";

int main(int a)
{ b[0]=(char)'\0'+-1;
return a;
}