int main(void)
{
    int a;
    int niz[10] = a;              // ne smije s desne strane biti niz, moze jedino biti konstantni niz
    return 0;
}
