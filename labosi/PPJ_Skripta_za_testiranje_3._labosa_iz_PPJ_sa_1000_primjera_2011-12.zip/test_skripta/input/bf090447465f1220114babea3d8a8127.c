char a = "\\";

int intaga = 5;

