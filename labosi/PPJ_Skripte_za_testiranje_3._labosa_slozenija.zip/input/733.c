char a[2]={'c'};
char main(void)
{
  return 'v';
}