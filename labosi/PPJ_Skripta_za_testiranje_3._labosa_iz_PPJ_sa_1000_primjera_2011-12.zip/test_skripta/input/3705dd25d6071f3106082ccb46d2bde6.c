char a[2]={'\x','c'};
int main(void)
{
  int x=a[99];
  return a[3]+2;
}