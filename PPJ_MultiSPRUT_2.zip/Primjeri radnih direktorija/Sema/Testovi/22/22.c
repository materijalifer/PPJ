void main(void){

int a[10] = "abc";
a[1]=12;
}