void fun(int a, char b[]) {
    return;
}

int main(void) {
    int A[512];
    const char tmp[] = "te  \nst";
    int a;
    a = 1 + 2 * 3;
    return 0;
}
