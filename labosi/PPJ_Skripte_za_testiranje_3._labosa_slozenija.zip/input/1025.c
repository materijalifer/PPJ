char a[2]={'\\','c'};
char main(void)
{
  return a[0.3]+'d';
}