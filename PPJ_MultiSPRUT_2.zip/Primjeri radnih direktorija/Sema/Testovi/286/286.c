
int main(void){
z=5;

return 0;
}