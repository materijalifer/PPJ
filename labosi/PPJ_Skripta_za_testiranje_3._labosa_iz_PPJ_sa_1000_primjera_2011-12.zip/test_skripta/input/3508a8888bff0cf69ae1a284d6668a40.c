int main(void){
 int y=90;
 int a[1024]="asd";
 char b='d';
// char c[5]="abc";
 b=y;
 return 0;
 }