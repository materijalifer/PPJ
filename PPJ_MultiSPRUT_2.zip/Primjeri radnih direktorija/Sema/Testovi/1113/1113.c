int main(void)
{
  int x,x;
  return 0;
}
