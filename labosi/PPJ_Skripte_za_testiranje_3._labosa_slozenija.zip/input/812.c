int a[2]={0,1};
int main(int a)
{
return a;
}