int a[2]={2};
char b[2]="x\0";
int main(int a)
{
return a;
}