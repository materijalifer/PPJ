int jednako(char a, char b) {
  if(a==b){
     return 1; 
  }else{
     return 0;
 }
}

 void greska(int x) {
   char a='a';
   return a;
 }

 int x=4;
 void f3(void) {
 int x=3;
 return x;
 }
 
 int main(void){
   int a;
   char i='a';
   char e='b';
   
   a=jednako(i,e);
   greska(1);
 return 1;
 }