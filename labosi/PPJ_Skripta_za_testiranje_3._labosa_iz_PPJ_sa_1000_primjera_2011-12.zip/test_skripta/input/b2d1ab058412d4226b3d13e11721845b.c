int x;
int y;
int main(void) {
  int z;
  int bla;
  int y, hg;
  
  x =  5;
return 0;
}