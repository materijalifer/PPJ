char x = "\\"";

int main(void) {return;}