int f(void)
{
  return 2;
}
int main(void)
{
  f(2);
  return 0;
}