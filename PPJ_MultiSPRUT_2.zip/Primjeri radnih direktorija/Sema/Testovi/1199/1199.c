char a[2] = "\\";

int intaga = 5;

int main(void) {
  return 0;
}

