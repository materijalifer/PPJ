int main(void)
{
return f();
}
char f(void)
{return 'f';}