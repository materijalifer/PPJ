int main(void) {
  int x = 3;
  int z;
  {
    int x = 5;
    int y = x + 1; // 6
    z = y + 1; // 7
  }
  z = x + 1; // 4
  return 0;
}