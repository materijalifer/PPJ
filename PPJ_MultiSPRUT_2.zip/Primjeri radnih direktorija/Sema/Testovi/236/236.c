int main (int a){
  int a;
return a;
}