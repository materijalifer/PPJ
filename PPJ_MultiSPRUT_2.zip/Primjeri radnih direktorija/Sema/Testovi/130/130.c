int x=3;
int main(void)

{
  int x=5;
  int y=x+1;
  int a[4]="bla\n";
  return 0;
}