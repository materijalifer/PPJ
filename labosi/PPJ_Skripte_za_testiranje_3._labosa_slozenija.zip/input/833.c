int main(void) {
  int j;
while (j)
    break;

  
  return 0;
}