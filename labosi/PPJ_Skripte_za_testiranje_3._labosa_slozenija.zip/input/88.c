int main(void) {
  char c = 'a';
  c = 1+c;
  return 0;
 }