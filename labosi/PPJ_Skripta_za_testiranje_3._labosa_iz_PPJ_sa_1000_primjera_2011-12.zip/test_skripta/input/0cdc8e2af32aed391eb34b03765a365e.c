
int main (void)
{
  int a=a+2;
  a=a+2;
}

