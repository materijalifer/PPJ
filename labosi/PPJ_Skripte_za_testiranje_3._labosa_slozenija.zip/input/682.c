int a = 100;

int main(void) {
  return 0;
}