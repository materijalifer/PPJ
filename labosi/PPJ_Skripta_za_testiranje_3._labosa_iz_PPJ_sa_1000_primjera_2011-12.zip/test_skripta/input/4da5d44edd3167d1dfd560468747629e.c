int main(void) {
 char c = 'a';
 c = (c + 1);
 return 0;
 }
 