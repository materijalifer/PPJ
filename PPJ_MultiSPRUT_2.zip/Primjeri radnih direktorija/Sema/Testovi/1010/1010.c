 
int main(void){
    int z = 0;
    int p(void);
    {
        int p = 3;
        {
            int p(void);
            z = p() + 2;
        }
    }
    return 0;
}

int p(void){
   return 12;
}
