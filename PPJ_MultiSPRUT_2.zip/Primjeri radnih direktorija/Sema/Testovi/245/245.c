int a = 5, c = 6, h = 7;
