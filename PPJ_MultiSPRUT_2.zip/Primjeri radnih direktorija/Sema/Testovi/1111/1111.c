
void foo (int x, int c, char h);

int f(void)
{
    return 0;
}

int x = 3;

 int deklaracijaBezDefinicije(int x);                 

int main(void)
{
    int a = 5;
    const char c = 'i';
    int niz[3];
    void foo (int x, int c, char h);
    int x = 5;
    int y = x + 1;
    a = a+3;
    
    if (a > 2)
    {
        int a;
        int b;
        a = b;
        x = 4;
    }
    return f();
}

int fact(int bzvz);

void foo (int x, int c, char h)
{
    int i = fact(x);
    int a = a+1;
    void foo3 (void);
    int niz1[5] = { 1, 2, 3 };
//    int niz[10] = a;                  
    for (i = 0; i < 5; i++)
        break;
    while(1)
    {
        break;
        i = i + 2;
    }
//  return 5;           
    return;
//  break;              
}

char proba3(void)
{
    x = 4;    
    if (0)
    {
        x = 6;  
        return 'a';
    } else {
        return (char)97;
//        return 97;            
    }
}

char proba(void)
{
    return (char)97;
}


int proba2(void)
{
//    i = 5;                
    return 'a';
}

int fact(int n)
{
    foo(1,2,'h');
    if (n > 0)
        return n * fact(n-1);
    else
        return 1;
}

void foo3(void)
{
    int i = 8;
//    main2();                 
    return;
}

void f2(int x, int a[]){
    x = x + 1;
  //  a[0] = a[0] + 1;
}

/*
int f2(int y)                       
{
    return 5;
}
*/

// char f2;                         

int main2(void) {
    int x = 2147483647, y;
//    int a = 2147483648;               
    (int)'a';
    (const char)x;
    (const int)'a';
    (char)((const int)300 + (int)'a');
    (int)(char)(const int)(const char)(x + y);

    return 0;
}
