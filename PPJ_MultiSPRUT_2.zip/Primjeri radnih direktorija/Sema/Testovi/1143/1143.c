int x;
char f(char x)
{
  {
  x++;
  }
  return (char)x;
}
int main(void)
{ 
  char x;
  return x;
}