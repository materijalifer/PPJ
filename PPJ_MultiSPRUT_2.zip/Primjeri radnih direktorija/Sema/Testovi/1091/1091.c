int main(int a)
{ 
  return 'a'|'\0'||2&'\''&&-0+--a+a+++'c'/000*-+a;
}
