int main(void) {
 int a[10];
 a[1][2]
 =8;
 return 0;
}


