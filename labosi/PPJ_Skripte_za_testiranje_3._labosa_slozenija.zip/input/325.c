int a[2]={2};
char b[6]="x\"\0\n\t";
int main(int a)
{
return a;
}