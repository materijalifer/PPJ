int x;
int main(void){

char x;

return 0;
}