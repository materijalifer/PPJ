int main(void)
{ 
  return 'a'|'\0'||2&'\''&&'\n';
}
