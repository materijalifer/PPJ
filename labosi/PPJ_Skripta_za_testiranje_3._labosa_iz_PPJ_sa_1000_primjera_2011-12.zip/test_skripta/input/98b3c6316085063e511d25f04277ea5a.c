int zbroji(int x, int y) {
  return x+y;  
}

int main(void) {
  const int a = 5;
  const int b = 2;
  zbroji(a,b);
  return 0;
}
