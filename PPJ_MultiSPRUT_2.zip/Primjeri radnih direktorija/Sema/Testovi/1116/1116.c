char a[2]={'\x','c'};
