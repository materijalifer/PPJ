int a [2];
int main(void)
{
  return a[0]+2;
}