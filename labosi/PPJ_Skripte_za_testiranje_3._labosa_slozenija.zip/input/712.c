
char a[4]='\';
