int x;
char x;
int main(int a)
{ 
  b[0]=(char)('\0'+b[-1]);
  return a;
}