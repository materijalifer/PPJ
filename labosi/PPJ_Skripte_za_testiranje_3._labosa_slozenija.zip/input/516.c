int main(){
int a = 5;
a = a+1;