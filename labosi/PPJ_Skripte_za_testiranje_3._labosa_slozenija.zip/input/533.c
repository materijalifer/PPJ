void p(void);

int main (char a){
//int p(vosid);
int c[12];
(a)=2;
a=(const char)c[1233];
return a;
}

void p (void){

return;}