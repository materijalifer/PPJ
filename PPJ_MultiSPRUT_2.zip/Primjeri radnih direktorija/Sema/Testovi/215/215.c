int main(void) {
  int i = 0;
  int n = 2;
  int a[2];
  while (i < n && a[i] = 2) {
    i++;
  }
  return 0;
}