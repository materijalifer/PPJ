int a[2]={0,2};
int main(int a)
{
return a;
}