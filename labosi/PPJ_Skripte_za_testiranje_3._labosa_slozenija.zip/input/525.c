int main(void)
{  
 int x=0;
 {
   int x=2;
   x++;
 }
return x/0;
}
