/*
 * LR1Constants.java
 *
 * THIS FILE HAS BEEN GENERATED AUTOMATICALLY. DO NOT EDIT!
 */

/**
 * An interface with constants for the parser and tokenizer.
 *
 *
 */
interface LR1Constants {

    /**
     * A token identity constant.
     */
    public static final int A = 1001;

    /**
     * A token identity constant.
     */
    public static final int B = 1002;

    /**
     * A token identity constant.
     */
    public static final int C = 1003;

    /**
     * A production node identity constant.
     */
    public static final int S = 2001;

    /**
     * A production node identity constant.
     */
    public static final int E = 2002;
}
