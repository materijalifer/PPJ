// komentar

int a[9] = "\\\\f";

int main(void) {
  return 0;
}