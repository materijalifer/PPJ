int b = 0x123;

int main(void) {
  return 0;
}
