int x=3;
int y=2;
int z;
z = x + y;