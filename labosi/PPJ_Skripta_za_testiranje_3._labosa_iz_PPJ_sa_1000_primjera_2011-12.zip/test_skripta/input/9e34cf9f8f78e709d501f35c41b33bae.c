int a,b,c = 5;

