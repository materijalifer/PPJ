int zbroji(int x, int y) {
  return x+y;  
}

int main(void) {
  const int a = 5;
  int b;
  zbroji(a,b);
  return 0;
}
