int f(void);
int main(void) {
  return f();
}
int f(void) {
  return 0;
}
