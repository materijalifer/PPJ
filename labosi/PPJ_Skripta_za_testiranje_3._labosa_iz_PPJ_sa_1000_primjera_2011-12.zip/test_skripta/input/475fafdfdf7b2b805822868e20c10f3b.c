int a(int a);

int b(int b);

int a(int a, int b);