int a[3] = "\\\\", c = 5;

int main(void) {
  return 0;
}