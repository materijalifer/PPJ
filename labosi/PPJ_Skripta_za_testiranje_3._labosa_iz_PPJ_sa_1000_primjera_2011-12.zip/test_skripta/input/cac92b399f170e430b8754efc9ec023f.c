void p(void);

int main (int a){
//int p(void);
int c[12];
a=c[12];
return a;
}

void p (void){

return;}