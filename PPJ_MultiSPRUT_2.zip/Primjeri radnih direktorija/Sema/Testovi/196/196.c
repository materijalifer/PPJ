int main(void){

int z='a';

return 0;
}