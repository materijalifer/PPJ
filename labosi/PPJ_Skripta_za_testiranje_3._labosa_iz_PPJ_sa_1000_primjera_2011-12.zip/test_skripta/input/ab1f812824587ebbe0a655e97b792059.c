void foo (void)
{
    return;
  break;              // break izvan petlje
}
