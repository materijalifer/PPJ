char x[5] = "\\"";

int main(void) {return 0;}