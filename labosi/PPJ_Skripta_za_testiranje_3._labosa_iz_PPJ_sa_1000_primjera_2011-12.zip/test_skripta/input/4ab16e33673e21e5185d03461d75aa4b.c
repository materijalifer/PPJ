int a(int a);

int b(int b);

int f(void) {
  return 0;
}

int a(int a) {return 4;}
int b(int b) {return 5;}

int main(void) {
  return 0;
}


