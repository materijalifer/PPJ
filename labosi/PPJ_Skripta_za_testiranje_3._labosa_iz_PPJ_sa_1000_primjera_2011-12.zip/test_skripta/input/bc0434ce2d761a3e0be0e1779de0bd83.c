int main(void) {
 char a[10] = 'ab';
 return 0;
}


