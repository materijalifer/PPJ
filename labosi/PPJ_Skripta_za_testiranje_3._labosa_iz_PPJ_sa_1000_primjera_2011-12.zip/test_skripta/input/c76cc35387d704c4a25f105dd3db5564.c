int main(void){
  char a[100]="haha";
  a [0]='a';
    return 0;
}