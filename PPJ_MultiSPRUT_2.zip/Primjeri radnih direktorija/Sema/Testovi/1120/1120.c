int main(void){
  char a[100]="haha";
  a [0]='a';
  puts(a);
    return 0;
}