// komentar

int a[0] = "\\\\f";

int main(void) {
  return 0;
}