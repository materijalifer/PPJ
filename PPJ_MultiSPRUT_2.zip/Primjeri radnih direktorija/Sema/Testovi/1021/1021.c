
char a[4]="\\";
