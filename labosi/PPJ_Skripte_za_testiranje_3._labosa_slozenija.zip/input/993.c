char a[6];
int main(void)
{
  int x=a[99];
  return a[3]+2;
}