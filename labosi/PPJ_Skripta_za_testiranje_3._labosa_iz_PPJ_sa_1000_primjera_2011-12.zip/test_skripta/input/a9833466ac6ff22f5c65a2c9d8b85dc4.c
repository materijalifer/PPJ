int main(void){
const int b;
b--;  
}
