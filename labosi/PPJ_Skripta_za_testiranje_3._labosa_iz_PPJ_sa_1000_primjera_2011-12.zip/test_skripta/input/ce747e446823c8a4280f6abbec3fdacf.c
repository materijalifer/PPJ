
int main(int b)
{ 
  char a[4]="\\\\";
  return 0;
}
