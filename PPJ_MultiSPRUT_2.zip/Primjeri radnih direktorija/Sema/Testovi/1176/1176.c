void fun(int a, char b[]) {
    return;
}

int main(void) {
    int a;
    a = 1 + 2 * 3;
    return 0;
}
