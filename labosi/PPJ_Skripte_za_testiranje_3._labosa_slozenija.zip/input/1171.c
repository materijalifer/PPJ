int main(void){

char z=1;

return 0;
}