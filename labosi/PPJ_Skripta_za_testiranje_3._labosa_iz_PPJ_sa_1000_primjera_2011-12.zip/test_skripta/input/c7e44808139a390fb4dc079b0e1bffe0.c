int a [2];
int main(void)
{
  return a[3]+2;
}