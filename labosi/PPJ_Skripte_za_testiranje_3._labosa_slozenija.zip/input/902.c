
int main (void)
{
  int a;
  return a+2;
}

