int main(void){
  char a[12]="dadada";
  int b=2;
  a[0]=(char)b;

  return 0;
}