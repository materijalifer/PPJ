int main(void)
{
printf ("/n");
return 0;
}
