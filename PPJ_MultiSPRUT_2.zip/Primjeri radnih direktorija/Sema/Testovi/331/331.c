// komentar

int a[1];

int main(void) {
  return 0;
}