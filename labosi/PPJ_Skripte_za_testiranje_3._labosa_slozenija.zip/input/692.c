int main(void)
{  
int a=2;
 if (a) 
 {
 a=+1;
 }else
 return 0;
 }
