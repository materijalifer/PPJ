char  f(void)
{return 'f';}
char main(void)
{
return f()+1;
}
