int a = 100;
char b = (char) 250;

int main(void) {
  return 0;
}