int funk(int x, int x)
{
return 0;
}