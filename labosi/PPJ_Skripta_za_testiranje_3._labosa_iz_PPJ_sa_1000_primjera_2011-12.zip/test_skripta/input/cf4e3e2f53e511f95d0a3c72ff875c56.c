int main(void) {
  char c = 'a';
  c = c + 1; // greska
  return 0;
}
