// komentar

int a[102] = "\\\\f";

int main(void) {
  return 0;
}