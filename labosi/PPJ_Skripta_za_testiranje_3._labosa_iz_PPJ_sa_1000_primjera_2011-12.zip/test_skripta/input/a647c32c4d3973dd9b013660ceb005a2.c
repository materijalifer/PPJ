int main(void){
int c[1000];
c[12]=5;
return 0;
}