int main(void){
char c[1000];
c[1]=2;
return 0;
}