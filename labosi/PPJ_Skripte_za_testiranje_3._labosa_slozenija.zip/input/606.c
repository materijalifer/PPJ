
int main (void)
{
  int a;
  a=a+2;
}

