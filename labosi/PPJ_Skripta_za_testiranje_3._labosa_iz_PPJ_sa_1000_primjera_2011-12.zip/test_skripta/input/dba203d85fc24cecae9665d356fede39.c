int main(void)
{  
int a=2;
 return a*+1/(0+--a%-a);
 }
