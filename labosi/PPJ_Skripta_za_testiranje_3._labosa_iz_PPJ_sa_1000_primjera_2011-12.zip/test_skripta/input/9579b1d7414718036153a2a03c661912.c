int main2(void) {
    int x = 5, y;
    return 0;
}
