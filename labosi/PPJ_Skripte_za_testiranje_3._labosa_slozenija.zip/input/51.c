int foo(void) {
  return 'a';
}

char bar(void) {
  return 97; // greska
}
