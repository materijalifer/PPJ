int main(void) {
 b=b+1;
 }