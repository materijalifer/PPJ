int a(int a);

int b(int b);

