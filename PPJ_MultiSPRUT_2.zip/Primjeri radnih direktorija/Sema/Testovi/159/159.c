 void p(void); //deklaracija funkcija
 int main(void){
 //    int p(int a); //nova neispravna deklaracija funkcije
     char a[122]="dada";
  char b[122]=a;
b[1]='s';
  p(); //poziv funkcije
     return 0;
 }

 void p(void){
    return;
}