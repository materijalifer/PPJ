void foo (int x, int c, char h);

int f(void) {
    return 0;
}

int x = 3;

// int deklaracijaBezDefinicije(int x);                 // deklaracija bez definicije

int main(void) {
    int a = 5;
    const char c = 'i';
    int niz[3];
    void foo (int x, int c, char h);
    int x = 5;
    int y = x + 1;
    a = a+3;
    
    if (a > 2)
    {
        int a;
        int b;
        a = b;
        x = 4;
    }
    return f();
}

int fact(int bzvz);

void foo (int x, int c, char h) {
    int i = fact(x);
    int a = a+1;
    void foo3 (void);
    break;              // break izvan petlje
    int niz1[5] = { 1, 2, 3 };
//    int niz[10] = a;              // ne smije s desne strane biti niz, moze jedino biti konstantni niz
    
    for (i = 0; i < 5; i++)
        break;
    
    while(1)
    {
        break;
        i = i + 2;
    }
//  return 5;           // vraca int a treba vracati void

    return;
    
}

char proba3(void) {
    x = 4;    // globalni x;
    if (0)
    {
        x = 6;   // globalni x;
        return 'a';
    } else {
        return (char)97;
//        return 97;            // int se ne moze implicitno u char castati
    }
}

char proba(void) {
    return (char)97;
}


int proba2(void) {
//    i = 5;                // nije deklarirano
    return 'a';
}

int fact(int n) {
    foo(1,2,'h');
    if (n > 0)
        return n * fact(n-1);
    else
        return 1;
}

void foo3(void) {
    int i = 8;
//    main2();                 // funkcija main2 je definirana tek kasnije, a nema deklaracije prije koja bi popravila ovu gresku
    return;
}

void f2(int x, int a[]){
    x = x + 1;
    a[0] = a[0] + 1;
}

/*
int f2(int y)                       // vec postoji definicija funkcije s istim imenom
{
    return 5;
}
*/

//char f2;                         // vec postoji funkcija s istim imenom

int main2(void) {
    int x = 2147483647, y;
//    int a = 2147483648;               // nije u rasponu int-a
    (int)'a';
    (const char)x;
    (const int)'a';
    (char)((const int)300 + (int)'a');
    (int)(char)(const int)(const char)(x + y);

    return 0;
}
