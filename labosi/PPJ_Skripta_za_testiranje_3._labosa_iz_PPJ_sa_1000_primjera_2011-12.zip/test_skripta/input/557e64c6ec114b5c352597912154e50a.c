int b,c,d,e,f,g;
int a = b = c = d = f = g = 1;

int main(void){return 0;}
