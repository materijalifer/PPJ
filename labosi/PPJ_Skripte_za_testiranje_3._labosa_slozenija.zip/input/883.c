int main(void)
{

  char c;
  c = (char)((const int)300 );

  
  //x = 10 ; y = 20 ;
  //z = (int)(char)(const int)(const char)(x+y);
  return 0;
}