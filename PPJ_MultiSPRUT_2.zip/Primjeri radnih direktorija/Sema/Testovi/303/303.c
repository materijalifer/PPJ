int main (void) {
  int a = 0;
  a = a+1;
  return 0;
}