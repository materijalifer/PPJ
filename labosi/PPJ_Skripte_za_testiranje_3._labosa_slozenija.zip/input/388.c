int a[2]={2};
int main(int a)
{
return a;
}