int  y = 3;
a=3;
void x(void) {
  int a;
    if (1)
        ;
    else if (2)
        y = 12;
    else
        y = 0;
}