int a[10] = "abc"; // isto kao redak 2
int b[10] = { 'a', 'b', 'c', '\0' };
int c[10] = { 97, 98, 99, 0 };
int d[10] = a; // greska