int x;
int y;
int main(void) {
  int z;
  int bla;
  int y = x+1;
return 0;
}