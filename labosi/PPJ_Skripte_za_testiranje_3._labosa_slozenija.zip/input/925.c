int main(void){

int z;
int z;

return 0;
}