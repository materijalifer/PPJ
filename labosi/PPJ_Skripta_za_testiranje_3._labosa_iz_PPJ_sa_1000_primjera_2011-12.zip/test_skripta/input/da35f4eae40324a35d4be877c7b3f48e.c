 int main(void) {
if(1){
while{
if(1){
int a;
a++
}
else{
break;
}
continue;
}}
 return 0;
 }