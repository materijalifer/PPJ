int y;
int x;

int zbrajanje(void){
  int x=3;
  int y=4;
  return x+y;
}

int main(void){
int z;
z=zbrajanje();

return 0;
}