

int main(void) {
  int a(int b);
  return 5;
}