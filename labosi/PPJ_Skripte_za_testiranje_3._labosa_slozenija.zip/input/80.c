char  f(void)
{return 'f';}
char main(void)
{  
 int x=0;
 {
   int x=2;
   x++;
 }
return f();
}
