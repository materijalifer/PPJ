int main(void){
int c[1000];
c=c;
return 0;
}