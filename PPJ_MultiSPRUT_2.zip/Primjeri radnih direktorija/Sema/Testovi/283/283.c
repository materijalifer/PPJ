int main(void)
{ 
  return 'a'|1;
}
