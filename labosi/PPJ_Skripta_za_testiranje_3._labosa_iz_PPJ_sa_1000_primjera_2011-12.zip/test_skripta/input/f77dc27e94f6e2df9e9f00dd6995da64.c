int b = -100000000000;

int main(void) {
  return 0;
}
