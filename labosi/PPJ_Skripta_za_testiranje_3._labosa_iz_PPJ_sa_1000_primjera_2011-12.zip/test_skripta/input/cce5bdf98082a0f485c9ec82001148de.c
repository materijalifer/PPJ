const int r=33;

void f(void){
return;
}
int main(void) {
char a = '6';

const char o=a;
const char e=o;

const char e;


char t;
int s=3;
{
int a = 5;
int y = e + 1; // 6
const int v=666;



s = y + 1; // 7
}
s = a + 1; // 4
return 0;
}