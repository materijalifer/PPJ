int main(void) {
int a = 666;
int z;
{
int a = 5;
int y = a + 1; // 6
z = y + 1; // 7
}
z = a + 1; // 4
return 0;
}