int main(void){
char c[1000]="\0";
return 0;
}