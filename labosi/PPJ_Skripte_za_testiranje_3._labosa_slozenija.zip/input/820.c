void foo (int x, int c, char h);

int f(void)
{
    return 0;
}

int x = 3;