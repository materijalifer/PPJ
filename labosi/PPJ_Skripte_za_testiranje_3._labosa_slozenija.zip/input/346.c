int a[2];
int main(int a)
{
return a;
}