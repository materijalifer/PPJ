int main(void) {
  int j;
  while (j) {
    break;
    for (;;) {
      break;
    }
    break;
  }

  
  return 0;
}