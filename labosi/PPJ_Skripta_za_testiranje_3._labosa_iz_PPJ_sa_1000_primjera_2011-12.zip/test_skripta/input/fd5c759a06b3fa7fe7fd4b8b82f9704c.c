void foo (int x, int c, char h)
{
    int a = a+1;
    void foo3 (void);
    int niz1[5] = { 1, 2, 3 };
    //int niz[10] = a;              // ne smije s desne strane biti niz, moze jedino biti konstantni niz
    
    for (i = 0; i < 5; i++)
        break;
    while(1)
    {
        break;
        i = i + 2;
    }
//    return 5;           // vraca int a treba vracati void
    return;
  break;              // break izvan petlje
}
