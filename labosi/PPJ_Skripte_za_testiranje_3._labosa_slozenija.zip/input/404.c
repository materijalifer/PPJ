 void f(int x, int a[]) {
 x = x + 1;
 a[0] = a[0] + 1;
 }

 int main(void) {
 int x = 3;
 int a[8] = x;
 f(x, a); // x == 3, a[0] == 1
 return 0;}