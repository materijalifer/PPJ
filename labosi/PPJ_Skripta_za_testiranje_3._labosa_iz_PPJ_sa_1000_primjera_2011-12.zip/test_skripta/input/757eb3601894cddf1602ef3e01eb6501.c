// komentar

int a[0];

int main(void) {
  return 0;
}