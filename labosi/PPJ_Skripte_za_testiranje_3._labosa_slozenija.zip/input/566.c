int main(void)
{  
int a=2;
 if (a-3)
 return 0;
 }
