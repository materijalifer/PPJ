int main(void) {
  int a[10];
  a[1]
  [2];
  return 0;
}
