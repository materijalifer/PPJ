Ulaz je preko stdin-a.
Primjer za upis:
<?xml version="1.0" encoding="UTF-8"?>