int x = 3;
int main(void) {
  int y = x + 1; // 4
  return 0;
}