int main(void){
char a[2]={'1','2'};
return 0;
}