int x;
int main(void){

int x=0;
while(x==0){
break;
}

return 0;
}