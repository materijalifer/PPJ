int funk(int x, char x)
{
return 0;
}