int main(void)
{  
int a=2;
 if (0)
 return 0;
 }
