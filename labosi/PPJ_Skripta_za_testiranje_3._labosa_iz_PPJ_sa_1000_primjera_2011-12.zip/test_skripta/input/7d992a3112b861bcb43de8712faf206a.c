int main(void){

int a[10] = "\";
char b='\"';
return 0;
}
