int b = 0x434;

int main(void) {
  return 0;
}
