int main(void) {
  char d[10]={'a','b','c'};
  char dd[10]={'d','e','f'};
  int a[10] = {0};
  a[0] = d[0] + dd[0]
  return 0;
}
