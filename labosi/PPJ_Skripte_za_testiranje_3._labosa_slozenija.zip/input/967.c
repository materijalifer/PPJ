void x(void) {
    int y;
    if (1)
        ;
    else if (2)
        y = 12;
    else
        y = 0;
}
