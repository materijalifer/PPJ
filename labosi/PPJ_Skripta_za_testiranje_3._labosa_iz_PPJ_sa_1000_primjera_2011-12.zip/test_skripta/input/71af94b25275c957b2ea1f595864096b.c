int main(int f) {
  return 0;
}