int f1(char a, char b) {
  return a == b;
}

void f2(int x) {
  return x;
}

void f3(void) {
  return;
}