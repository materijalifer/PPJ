 
int main (void)
{
  {
  int f(void);f();
  }
  //{
   int f(void)
    {
      return 0;
    }f();
  //}
  return 0;
}