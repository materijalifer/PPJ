int main(void){
const int a[10];

a[1]=3;

return 0;
}