int printf(const char format[]) {
  /* i wisghkhhhhjhjh i could printf */
  return 0;
}

int main(void) {
  return printf("hello world!\n");
}
