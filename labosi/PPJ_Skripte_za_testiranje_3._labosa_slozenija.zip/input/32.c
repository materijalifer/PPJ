int main(void){

int a[10] = "abc";
char b='s';
return 0;
}
