int main(void)
{ 
  return 'a'|'\0'||2&'\''&&'\x0;
}
