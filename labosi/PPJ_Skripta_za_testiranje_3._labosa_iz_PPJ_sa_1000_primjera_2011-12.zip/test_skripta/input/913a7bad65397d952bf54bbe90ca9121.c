int main(void) {
    int x = 5, y;
    return 0;
}
