int x;
int y;

int main(void){
int z;
return 0;
}