
int main(void){
  void p(int a, int b);
  int a=12;
  int polje[4]={1,'c',3};
  a=3+3;
  
}

void p( int a, int b) {
  void p(int a);

  return;
}


void p(int a)
{

return;

}
