int a[2]={2};
char b[2]="x";
int main(int a)
{
return a;
}