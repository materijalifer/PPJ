void f2(int x, int a[]){
    x = x + 1;
    a[0] = a[0] + 1;
}

char f2;
