int b = -1000000000;

int main(void) {
  return 0;
}
