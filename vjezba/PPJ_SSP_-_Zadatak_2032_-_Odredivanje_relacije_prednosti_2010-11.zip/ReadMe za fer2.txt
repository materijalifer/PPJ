Znala mi se javljati povremeno neobja�njiva gre�ka 
prilikom konstantnog: mjenjanja datoteke pa nakon 
toga kopajliranja, pri �emu je kompajliranje javilo error, 
kojeg sam rje�io malo �ekaju�i...koliko se god smje�no 
to �inilo. Mislim da sam malo pretjerao sa rekurzijama, pa
je RAM trebao malo vremena da o�ivi, valjda.

P.S. Nisam siguran da li sam slu�ajno radio Solution u 
.NET 4.0, jer sam programirao u VS2010, pa ako se javalja
error da vam fali neki .dll ili neki Windows error, onda
je caka da nemate instaliran .NET 4.0. Samo skopiratjte 
kod u novi Solution, pa kompajliratjte. Za bilokakva pitanja
slobodno se javite.