int main(void) {
  int f = 6;
  int a[3] = {f+d,2,3+4};
  return 0;
}
