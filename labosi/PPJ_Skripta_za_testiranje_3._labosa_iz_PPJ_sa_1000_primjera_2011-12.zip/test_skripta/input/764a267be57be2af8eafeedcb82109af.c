int main(void) {
  int f(int a, int b, int c);
  int f(int a, int b);
  return 0;
}
