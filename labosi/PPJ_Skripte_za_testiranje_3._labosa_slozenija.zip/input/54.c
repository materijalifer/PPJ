 
int zbroji(int x, int y) {
  return x+y;  
}

int main(void) {
  char a = 'a';
  const int b = 2;
  zbroji(a,b);
  return 0;
}
