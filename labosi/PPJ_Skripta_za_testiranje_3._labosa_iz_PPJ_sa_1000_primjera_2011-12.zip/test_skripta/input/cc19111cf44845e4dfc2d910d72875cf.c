int main(void) {
 char c = 'a';
 c = (char)(c + 1);
 return 0;
 }
 