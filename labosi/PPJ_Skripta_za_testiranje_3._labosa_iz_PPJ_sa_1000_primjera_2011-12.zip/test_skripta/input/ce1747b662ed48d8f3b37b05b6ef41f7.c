int x=x=2;
void main(void)
{
  return 0;
}