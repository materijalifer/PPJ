void p(void);

int main (int a){
//int p(void);
int c[12];
a=c;
return a;
}

void p (void){

return;}