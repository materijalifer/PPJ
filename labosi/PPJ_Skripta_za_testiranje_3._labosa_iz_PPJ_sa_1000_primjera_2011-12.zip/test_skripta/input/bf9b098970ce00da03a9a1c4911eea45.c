int x;
int y;
int main(void) {
  int z;
  int bla;
  int y;
return 0;
}