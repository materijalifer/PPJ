int main(int a, int b){
const int g[10];

a[1]=3;

return 0;
}