int a,b,c;

int main(void) {
a = "sdlkjfhksjdf";
return 0;
}