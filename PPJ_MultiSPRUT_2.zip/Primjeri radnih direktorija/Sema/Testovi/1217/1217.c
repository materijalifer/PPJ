char a[2] = "\\", g = (char)5;

int intaga = 5;

int main(void) {
  return 0;
}

