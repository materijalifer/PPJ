char a[2]={'\0','c'};
int main(void)
{
  int x=a[99];
  return a[3]+2;
}