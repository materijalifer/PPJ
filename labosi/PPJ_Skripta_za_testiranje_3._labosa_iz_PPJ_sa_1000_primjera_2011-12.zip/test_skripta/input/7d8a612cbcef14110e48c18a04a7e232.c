int main(void) {
  int y = x + 1; // greska
  return 0;
}
int x = 3;