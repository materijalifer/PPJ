int f(int a):
  return 1;
int main(void) {
 f();
 return 0;
 }