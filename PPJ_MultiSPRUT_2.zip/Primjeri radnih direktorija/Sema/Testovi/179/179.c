int a[2]={2};
char b[8]="\"\0\n\t\\"";

int main(int a)
{ b[0]='\0'++;
return a;
}