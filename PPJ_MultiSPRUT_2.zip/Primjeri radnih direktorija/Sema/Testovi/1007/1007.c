char a[2] = "\\";

int main(void) {
  return 0;
}
