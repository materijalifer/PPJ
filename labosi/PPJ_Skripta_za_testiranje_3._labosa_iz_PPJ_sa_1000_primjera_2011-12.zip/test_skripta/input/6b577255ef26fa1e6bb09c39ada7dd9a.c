int main(void){
int c[1000];
c[100]=c;
return 0;
}