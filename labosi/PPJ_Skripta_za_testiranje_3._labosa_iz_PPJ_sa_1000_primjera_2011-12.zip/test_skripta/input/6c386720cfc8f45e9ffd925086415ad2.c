void f(void);
int x = 3;
int main(void) {
  int x = 5;
  int y = x + 1; // 6
  for (;;) {
    break;
  }
  return 0;
}
