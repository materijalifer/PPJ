int main(void){
char c[1000];
c='s';
return 0;
}