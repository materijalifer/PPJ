int main(void) {
  char c;
  c = 'bla';
  return 0;
}
