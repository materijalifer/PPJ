int f():
  return 1;
int main(void) {
 f(5);
 return 0;
 }