int a[2]={2};
char b[8]="x\"\0\n\t\\"";
b[0]='a';
int main(int a)
{
return a;
}