void main(void){
  void p(void);
  p();
  if(1){
  while(0){
int a;
  if(1){
  a++;
}
else{
{
  continue;
return;
} 
}
}
}


}

void p(int a){
  return;
}