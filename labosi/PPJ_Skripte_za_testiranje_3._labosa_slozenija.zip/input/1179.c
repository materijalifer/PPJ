int main(void)
{  
 int x ;
 {
   char x=(char)(int)(char)2;
   x++;
 }
return x/0;
}
