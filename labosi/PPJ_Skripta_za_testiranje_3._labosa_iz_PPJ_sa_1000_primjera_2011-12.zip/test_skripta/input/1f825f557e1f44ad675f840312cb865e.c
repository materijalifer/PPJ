int main(void)
{

return printf ("/n");
}
