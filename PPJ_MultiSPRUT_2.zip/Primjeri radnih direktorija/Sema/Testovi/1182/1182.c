int main(void) {
  int j;
  for (j = 0; j < 10; ++j)
    break;
  break;
  return 0;
}