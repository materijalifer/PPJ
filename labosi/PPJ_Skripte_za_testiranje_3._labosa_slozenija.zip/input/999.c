 
int main (void)
{
  {
  int f(void);f();
  }
  //{
   int f(void)
    {
      return 0;
    }
  //}
  return 0;
}